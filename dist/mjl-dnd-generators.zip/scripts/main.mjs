import { LIBRARY, rollSpellbook, TIERS, TIER_LABELS } from "./rules.mjs";
import { openArmory, openArt, openGems, openGoods } from "./stock.mjs";
import { gold, itemButton, itemCard, previewStatus, tierOptions } from "./ui.mjs";

const ID = "mjl-dnd-generators";
const DIALOG_ID = `${ID}-spellbook`;
const BOOK_SOURCES = ["ag-fifthpendium.equipment", "fifthpendium.items"];
const BOOK_TYPES = new Map([
  ["ordinary", { identifier: "spellbook", label: "Обычная книга заклинаний" }],
  ["enduring", { identifier: "enduring-spellbook", label: "Вечная книга заклинаний" }]
]);
const SUPPLEMENTS = new Map([
  ["ag-fifthpendium-arcana-unleashed", "Arcana Unleashed"],
  ["ag-fifthpendium-forgotten-realms", "Forgotten Realms"],
  ["ag-fifthpendium-dndbeyond", "D&D Beyond"]
]);
const formatNumber = new Intl.NumberFormat("ru-RU");

Hooks.on("getSceneControlButtons", controls => {
  if (!game.user.isGM || game.system.id !== "dnd5e") return;
  controls[ID] = {
    name: ID,
    title: "Генераторы",
    icon: "fa-solid fa-dice-d20",
    order: 20,
    tools: {
      spellbook: {
        name: "spellbook",
        title: "Книга заклинаний волшебника",
        icon: "fa-solid fa-book-sparkles",
        order: 1,
        button: true,
        onChange: openSpellbook
      },
      gems: { name: "gems", title: "Самоцветы", icon: "fa-solid fa-gem", order: 2, button: true, onChange: openGems },
      armory: { name: "armory", title: "Ассортимент оружейной", icon: "fa-solid fa-swords", order: 3, button: true, onChange: openArmory },
      art: { name: "art", title: "Предметы искусства", icon: "fa-solid fa-palette", order: 4, button: true, onChange: openArt },
      goods: { name: "goods", title: "Товары", icon: "fa-solid fa-boxes-stacked", order: 5, button: true, onChange: openGoods }
    }
  };
});

async function loadBase(kind) {
  const book = BOOK_TYPES.get(kind);
  if (!book) throw new Error("Выберите вид книги заклинаний.");
  for (const id of BOOK_SOURCES) {
    const pack = game.packs.get(id);
    if (!pack) continue;
    const index = await pack.getIndex({ fields: ["system.identifier"] });
    const entry = index.find(item => item.system?.identifier === book.identifier);
    if (entry) return pack.getDocument(entry._id);
  }
  throw new Error(`В подключённых библиотеках Fifthpendium не найден предмет «${book.label}».`);
}

async function loadSpellPool(excluded) {
  const allowed = pack => LIBRARY.test(pack.collection) && !excluded.has(pack.collection.split(".")[0]);
  const journals = game.packs.filter(pack => pack.documentName === "JournalEntry" && allowed(pack));
  const pages = await Promise.all(journals.map(async pack => {
    const index = await pack.getIndex({ fields: ["pages.type", "pages.system.type", "pages.system.identifier"] });
    const matches = await Promise.all(index.contents.map(async journal => {
      if (!journal.pages) return [];
      // Foundry can replace a nested page index with a partial object after loading the journal.
      const pages = Array.isArray(journal.pages) ? journal.pages : (await pack.getDocument(journal._id))?.pages.contents;
      return (pages ?? [])
        .filter(page => page.type === "spells" && page.system?.type === "class" && page.system.identifier === "wizard")
        .map(page => page.uuid ?? `${journal.uuid}.JournalEntryPage.${page._id}`);
    }));
    return matches.flat();
  }));
  const lists = await Promise.all(pages.flat().map(uuid => fromUuid(uuid)));
  const uuids = new Set(lists.filter(Boolean).flatMap(list => [
    ...list.system.spells, ...list.system.unlinkedSpells.map(spell => spell.source?.uuid)
  ]));

  const byPack = new Map();
  for (const uuid of uuids) {
    if (!uuid?.startsWith("Compendium.")) continue;
    const { collection, documentId } = foundry.utils.parseUuid(uuid);
    if (collection?.documentName !== "Item" || !allowed(collection)) continue;
    if (!byPack.has(collection)) byPack.set(collection, new Set());
    byPack.get(collection).add(documentId);
  }

  const spells = await Promise.all(Array.from(byPack, async ([pack, ids]) => {
    const index = await pack.getIndex({ fields: ["system.level", "system.identifier", "system.source.rules"] });
    return Array.from(ids, id => index.get(id)).filter(entry => entry?.type === "spell").map(entry => ({
      key: entry.system.identifier || entry.name.trim().toLowerCase(),
      uuid: entry.uuid,
      name: entry.name,
      level: entry.system.level,
      priority: (entry.system.source?.rules === "2024" ? 2 : 0) + Number(pack.collection.startsWith("ag-"))
    }));
  }));
  const pool = spells.flat().sort((a, b) => b.priority - a.priority);
  if (!pool.length) throw new Error("В подключённых библиотеках не найден список заклинаний волшебника.");
  return pool;
}

function spellContents(spells, renderSpell) {
  const groups = Map.groupBy(spells.toSorted((a, b) => a.level - b.level || a.name.localeCompare(b.name, "ru")), spell => spell.level);
  const entries = document.createElement("div");
  entries.className = "mjl-book-entries";
  for (const [level, group] of groups) {
    const circle = document.createElement("section");
    circle.className = "mjl-book-circle";
    const heading = document.createElement("h4");
    heading.textContent = `Круг ${level}`;
    const list = document.createElement("ul");
    for (const spell of group) {
      const li = document.createElement("li");
      li.append(renderSpell(spell));
      list.append(li);
    }
    circle.append(heading, list);
    entries.append(circle);
  }
  return entries;
}

function openSpellbook() {
  const existing = foundry.applications.instances.get(DIALOG_ID);
  if (existing) return existing.bringToFront();

  const { DialogV2 } = foundry.applications.api;
  let result;
  let saved = false;
  let busy = false;

  const dialog = new DialogV2({
    id: DIALOG_ID,
    classes: ["mjl-brand", ID],
    window: { title: "MJl - DnD Generators", icon: "fa-solid fa-book-sparkles", resizable: true },
    position: { width: 800 },
    form: { closeOnSubmit: false },
    content: `
      <header class="mjl-book-heading">
        <span class="mjl-book-glyph"><i class="fa-solid fa-book-sparkles" aria-hidden="true"></i></span>
        <div><h2>Книга заклинаний волшебника</h2><p>Трофей из компендиумов Fifthpendium</p></div>
      </header>
      <div class="mjl-book-layout">
        <fieldset class="mjl-book-options" aria-label="Параметры книги">
          <label>Тир партии<select name="tier">${tierOptions()}</select></label>
          <label>Уровень волшебника<select name="level"></select></label>
          <label>Вид книги<select name="kind">${Array.from(BOOK_TYPES, ([key, book]) =>
            `<option value="${key}">${book.label}</option>`).join("")}</select></label>
          <fieldset class="mjl-book-sources"><legend>Дополнительные источники</legend>
            ${Array.from(SUPPLEMENTS, ([id, label]) => {
              const active = game.modules.get(id)?.active;
              return `<label><input type="checkbox" name="${id}" ${active ? "checked" : "disabled"}>
                <span>${label}${active ? "" : "<small>Не подключено</small>"}</span></label>`;
            }).join("")}
          </fieldset>
        </fieldset>
        <section class="mjl-book-result" aria-label="Предпросмотр книги">
          <div class="mjl-book-preview">${previewStatus("Выберите параметры и сгенерируйте книгу.")}</div>
          <div class="mjl-book-created" hidden></div>
        </section>
      </div>`,
    buttons: [
      { action: "roll", label: "Сгенерировать", icon: "fa-solid fa-dice", default: true,
        callback: (_event, button) => generate(button.form) },
      { action: "save", label: "Создать предмет", icon: "fa-solid fa-box-archive", disabled: true,
        callback: (_event, button) => save(button.form) }
    ],
    // DialogV2 restores the previous button states after this callback.
    submit: () => setTimeout(syncSave, 0)
  });

  function syncSave() {
    const button = dialog.element?.querySelector('[data-action="save"]');
    if (button) button.disabled = !result || saved || busy;
  }

  async function generate(form) {
    if (busy) return;
    const preview = form.querySelector(".mjl-book-preview");
    const created = form.querySelector(".mjl-book-created");
    const { tier, level, kind } = form.elements;
    const settings = form.querySelector(".mjl-book-options");
    const selectedTier = Number(tier.value);
    const wizardLevel = Number(level.value);
    settings.disabled = busy = true;
    result = undefined;
    saved = false;
    created.hidden = true;
    preview.innerHTML = previewStatus("Читаю библиотеки и подбираю заклинания…", "fa-hourglass-half");
    try {
      const base = await loadBase(kind.value);
      const excluded = new Set(Array.from(SUPPLEMENTS.keys()).filter(id => !form.elements.namedItem(id).checked));
      const pool = await loadSpellPool(excluded);
      const book = rollSpellbook(pool, selectedTier, wizardLevel);
      const { value, denomination } = base.system.price;
      const conversion = CONFIG.DND5E.currencies[denomination]?.conversion;
      if (!Number.isFinite(value) || !conversion) throw new Error("У исходной книги нет корректной цены.");
      const basePrice = value / conversion;
      const price = basePrice + book.contentsPrice;
      const contents = spellContents(book.spells, spell => `@UUID[${spell.uuid}]`);
      const data = game.items.fromCompendium(base, { clearFolder: true });
      data.name = `${base.name} · волшебник ${wizardLevel}-го уровня`;
      data.system.price = { value: price, denomination: "gp" };
      data.system.description.value += `<section class="mjl-book-entries"><h3>Записи волшебника ${wizardLevel}-го уровня</h3>${contents.innerHTML}</section>`;
      data.flags[ID] = { tier: selectedTier, wizardLevel, spells: book.spells.map(spell => spell.uuid) };
      const item = new CONFIG.Item.documentClass(data);
      preview.innerHTML = `
        <div class="mjl-book-facts"><span>Тир ${TIER_LABELS[selectedTier - 1]}</span>
          <span>Уровень ${wizardLevel}</span><span>Заклинаний: ${book.spells.length}</span></div>
        <div class="mjl-book-price"><div><span>Цена находки</span><strong>${gold(price)}</strong></div>
          <small>${gold(basePrice)} за книгу + ${gold(book.contentsPrice)} за записи</small></div>
        <p class="mjl-book-copy">Переписать всё: ${gold(book.copyCost)} · ${formatNumber.format(book.copyHours)} ч.</p>`;
      preview.prepend(itemCard(item, "Открыть сгенерированную книгу"));
      preview.append(spellContents(book.spells, spell => itemButton(spell)));
      result = data;
    } catch (error) {
      preview.innerHTML = previewStatus(error.message, "fa-triangle-exclamation");
      console.error(ID, error);
    } finally {
      settings.disabled = busy = false;
      if (dialog.rendered) dialog.setPosition();
    }
  }

  async function save(form) {
    if (!game.user.isGM || !result || saved || busy) return;
    const settings = form.querySelector(".mjl-book-options");
    settings.disabled = busy = true;
    try {
      const item = await Item.create(foundry.utils.deepClone(result));
      if (!item) throw new Error("Создание предмета отменено.");
      saved = true;
      const created = form.querySelector(".mjl-book-created");
      created.replaceChildren(itemCard(item, "Открыть созданную книгу"));
      created.hidden = false;
      if (dialog.rendered) dialog.setPosition();
      ui.notifications.info("Книга добавлена во вкладку «Предметы».");
      item.sheet.render({ force: true });
    } catch (error) {
      ui.notifications.error(error.message);
      console.error(ID, error);
    } finally {
      settings.disabled = busy = false;
    }
  }

  dialog.addEventListener("render", () => {
    const form = dialog.element.querySelector("form");
    const { tier, level } = form.elements;
    const setLevels = () => {
      const [min, max] = TIERS[Number(tier.value) - 1];
      level.replaceChildren(...Array.from({ length: max - min + 1 }, (_, i) => new Option(min + i, min + i)));
    };
    const clearResult = () => {
      if (!result) return;
      result = undefined;
      form.querySelector(".mjl-book-created").hidden = true;
      form.querySelector(".mjl-book-preview").innerHTML = previewStatus("Настройки изменились. Сгенерируйте новую книгу.");
      syncSave();
    };
    form.addEventListener("change", event => {
      if (event.target === tier) setLevels();
      clearResult();
    });
    setLevels();
  }, { once: true });
  return dialog.render({ force: true });
}
